imageapp Django project
----------------------
This is a minimal Django project that serves a single page showing your image (viewer/index.html).
It assumes you have Python 3 and Django installed on the machine where you run it.

How to run:
1. (Optional) create a virtual environment and activate it:
   python3 -m venv venv
   source venv/bin/activate

2. Install Django if not already installed:
   pip install Django

3. Run migrations (creates a tiny sqlite DB):
   python3 manage.py migrate

4. Run the development server on port 90 (requires sudo because port <1024):
   sudo python3 manage.py runserver 0.0.0.0:90

5. Open in your browser:
   http://localhost:90/

Notes:
- The static image is located at viewer/static/qr_chall.jpg
- If you change DEBUG to False, update ALLOWED_HOSTS appropriately in imageapp/settings.py
