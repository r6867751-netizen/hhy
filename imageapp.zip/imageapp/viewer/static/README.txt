This folder contains static assets.
