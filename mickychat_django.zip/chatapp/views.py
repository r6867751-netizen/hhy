from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.conf import settings
import json

EXPECTED = {
    'password': 'MickyCTFPGM@OHATVM',
    'bet_code': 'PR253BTCD2023',
    'receipt': 'GG-2024-0078',
    'bet_amount': 500.0,
}

def chat_page(request):
    request.session.setdefault('step', 0)
    return render(request, 'chatapp/chat.html')

@require_POST
def message_api(request):
    try:
        data = json.loads(request.body.decode())
        message = data.get('message', '').strip()
    except Exception:
        return JsonResponse({'ok': False, 'reply': 'Invalid request'}, status=400)

    step = request.session.get('step', 0)
    lower = message.lower()

    if step == 0:
        if lower == 'hi':
            request.session['step'] = 1
            return JsonResponse({'ok': True, 'reply': 'Please share the **Micky password**.'})
        return JsonResponse({'ok': True, 'reply': "I didn't understand. Please start by saying 'hi'."})

    if step == 1:
        if message == EXPECTED['password']:
            request.session['step'] = 2
            return JsonResponse({'ok': True, 'reply': 'Password accepted! ✅ Now, please share your **bet code**.'})
        return JsonResponse({'ok': True, 'reply': '❌ Incorrect Micky password. Please try again.'})

    if step == 2:
        if message == EXPECTED['bet_code']:
            request.session['step'] = 3
            return JsonResponse({'ok': True, 'reply': 'Hurray! You got it. Now please share the **receipt number**.'})
        return JsonResponse({'ok': True, 'reply': 'Invalid bet code. Try again.'})

    if step == 3:
        if message == EXPECTED['receipt']:
            request.session['step'] = 4
            return JsonResponse({'ok': True, 'reply': 'Great! Now please share your **bet amount**.'})
        return JsonResponse({'ok': True, 'reply': 'Receipt did not match. Try again.'})

    if step == 4:
        try:
            amount = float(message.replace('$', '').replace(',', '').strip())
        except Exception:
            return JsonResponse({'ok': True, 'reply': '❌ Please provide a numeric bet amount.'})
        if amount == EXPECTED['bet_amount']:
            flag = getattr(settings, 'MICKY_FLAG', None)
            if not flag:
                return JsonResponse({'ok': True, 'reply': 'Flag not configured.'})
            request.session['step'] = 5
            return JsonResponse({'ok': True, 'reply': f'🎉 Your Flag is: **{flag}**'})
        return JsonResponse({'ok': True, 'reply': '❌ Incorrect bet amount.'})

    return JsonResponse({'ok': True, 'reply': 'Unrecognized input.'})
