1. Create a virtualenv and install requirements:
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt

2. Copy .env.example to .env and set values (especially MICKY_FLAG and DJANGO_SECRET_KEY)

3. Run migrations (no models but run to ensure session table is created):
   python manage.py migrate

4. Run the development server on port 401:
   python manage.py runserver 0.0.0.0:401

   (If you prefer production, use gunicorn and configure ALLOWED_HOSTS & static files)

5. Open http://127.0.0.1:401/ in your browser.

Notes:
- The flag should be set in the environment variable MICKY_FLAG. Example:
    export MICKY_FLAG='AIB{INDV/SAUS-2023-FNLMTCH}'

- For extra security in production, set DEBUG=False, use a strong SECRET_KEY, and serve behind a reverse proxy with HTTPS.
