from django.core.management.base import BaseCommand
from django.contrib.auth.hashers import make_password
from mickychat.models import MickyChallenge

class Command(BaseCommand):
    help = 'Create or update Micky challenge secrets.'

    def add_arguments(self, parser):
        parser.add_argument('--password', required=True)
        parser.add_argument('--betcode', required=True)
        parser.add_argument('--receipt', required=True)
        parser.add_argument('--amount', type=float, default=500.0)

    def handle(self, *args, **opts):
        obj, _ = MickyChallenge.objects.get_or_create(pk=1)
        obj.password_hash = make_password(opts['password'])
        obj.betcode_hash = make_password(opts['betcode'])
        obj.receipt_hash = make_password(opts['receipt'])
        obj.bet_amount = opts['amount']
        obj.attempts = 0
        obj.locked_until = None
        obj.save()
        self.stdout.write(self.style.SUCCESS('Micky challenge configured.'))
