from django.db import models
from django.contrib.auth.hashers import make_password, check_password
from django.utils import timezone
from datetime import timedelta

class MickyChallenge(models.Model):
    name = models.CharField(max_length=100, default="Micky Chat Challenge")
    password_hash = models.CharField(max_length=255)
    betcode_hash = models.CharField(max_length=255)
    receipt_hash = models.CharField(max_length=255)
    bet_amount = models.DecimalField(max_digits=10, decimal_places=2, default=500.00)
    attempts = models.IntegerField(default=0)
    locked_until = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def check_password(self, raw):
        return check_password(raw, self.password_hash)

    def check_betcode(self, raw):
        return check_password(raw, self.betcode_hash)

    def check_receipt(self, raw):
        return check_password(raw, self.receipt_hash)

    def lock(self, minutes=15):
        self.locked_until = timezone.now() + timedelta(minutes=minutes)
        self.attempts = 0
        self.save()

    def is_locked(self):
        return self.locked_until and timezone.now() < self.locked_until

    def register_failed_attempt(self, max_attempts=5, lock_minutes=15):
        self.attempts += 1
        if self.attempts >= max_attempts:
            self.lock(lock_minutes)
        else:
            self.save()
