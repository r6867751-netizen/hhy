from django.apps import AppConfig

class MickychatConfig(AppConfig):
    name = 'mickychat'
