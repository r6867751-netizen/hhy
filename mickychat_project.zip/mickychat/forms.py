from django import forms

class StepForm(forms.Form):
    step = forms.IntegerField(widget=forms.HiddenInput())
    value = forms.CharField(max_length=255)

    def clean_value(self):
        v = self.cleaned_data['value'].strip()
        if v == '':
            raise forms.ValidationError('Empty value not allowed.')
        return v
