from django.urls import path
from . import views

app_name = 'mickychat'
urlpatterns = [
    path('', views.chat_view, name='chat'),
    path('api/step/', views.api_step, name='api_step'),
]
