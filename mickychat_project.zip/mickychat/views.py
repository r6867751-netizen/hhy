from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.conf import settings
from .models import MickyChallenge
from .forms import StepForm
import hmac, hashlib

def generate_flag(challenge, session_id):
    msg = f"{challenge.pk}:{session_id}:{int(challenge.created_at.timestamp())}"
    digest = hmac.new(settings.SECRET_KEY.encode(), msg.encode(), hashlib.sha256).hexdigest()
    token = digest[:24].upper()
    return f"AIB{{{token}}}"

def chat_view(request):
    challenge, _ = MickyChallenge.objects.get_or_create(pk=1)
    if 'micky_step' not in request.session:
        request.session['micky_step'] = 0
    return render(request, 'mickychat/chat.html', {'step': request.session['micky_step']})

@require_POST
def api_step(request):
    form = StepForm(request.POST)
    if not form.is_valid():
        return JsonResponse({'ok': False, 'msg': 'Invalid input.'}, status=400)

    step = form.cleaned_data['step']
    value = form.cleaned_data['value']
    challenge = MickyChallenge.objects.get(pk=1)

    if challenge.is_locked():
        return JsonResponse({'ok': False, 'msg': 'Challenge locked. Try later.'}, status=403)

    if step == 0 and value.lower() == 'hi':
        request.session['micky_step'] = 1
        return JsonResponse({'ok': True, 'msg': 'Please share the Micky password.'})
    if step == 1:
        if challenge.check_password(value):
            request.session['micky_step'] = 2
            return JsonResponse({'ok': True, 'msg': 'Password accepted! Share bet code.'})
        challenge.register_failed_attempt()
        return JsonResponse({'ok': False, 'msg': 'Incorrect password.'}, status=403)
    if step == 2:
        if challenge.check_betcode(value):
            request.session['micky_step'] = 3
            return JsonResponse({'ok': True, 'msg': 'Bet code accepted! Share receipt.'})
        challenge.register_failed_attempt()
        return JsonResponse({'ok': False, 'msg': 'Incorrect bet code.'}, status=403)
    if step == 3:
        if challenge.check_receipt(value):
            request.session['micky_step'] = 4
            return JsonResponse({'ok': True, 'msg': 'Receipt accepted! Share amount.'})
        challenge.register_failed_attempt()
        return JsonResponse({'ok': False, 'msg': 'Incorrect receipt.'}, status=403)
    if step == 4:
        try:
            amt = float(value.replace(',', '').replace('$', ''))
        except:
            challenge.register_failed_attempt()
            return JsonResponse({'ok': False, 'msg': 'Invalid amount.'}, status=400)
        if abs(amt - float(challenge.bet_amount)) < 0.0001:
            flag = generate_flag(challenge, request.session.session_key or 'anon')
            request.session['micky_step'] = 5
            return JsonResponse({'ok': True, 'msg': f'🎉 Your Flag is: {flag}'})
        challenge.register_failed_attempt()
        return JsonResponse({'ok': False, 'msg': 'Incorrect amount.'}, status=403)

    return JsonResponse({'ok': False, 'msg': 'Unexpected input.'}, status=400)
